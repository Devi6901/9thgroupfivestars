from django.shortcuts import render

def index(request):
	return render(request, 'nestaway/index.html')
def aboutus(request):
	return render(request, 'nestaway/aboutus.html')
def blog(request):
	return render(request, 'nestaway/blog.html')

