from django.apps import AppConfig


class NestawayConfig(AppConfig):
    name = 'nestaway'
